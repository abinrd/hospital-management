# Challenge 0

This is the most basic challenge in the CTF. The flag can be found by opening the browser dev tools and finding the HTML comment containing the flag.

Difficulty: Easy