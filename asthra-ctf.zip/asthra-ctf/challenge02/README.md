## Challenge 2

This is the basic challenge in the CTF. The flag can be found by inspecting the source code and consoles appropriate variable. The clues to flag can be found from hidden files in the terminal.

# Steps:
1. First need to use some simple linux commands to find a hidden file that has a clue.
2. After the clue there is also another hidden file with a encrypted message with ceaser cipher when they decrypt,it may help them to find the flag.
3. After decrypting the text we found that flag is hidden in source code.. need to inspect source code carefully and to know how the code works..to find the flag.
4. After consoling the variable they will get flag value.

# Flag
`asthra{np/I2iffnFuWs7+TfZFEaoEdVMtOC3FFdWd34uvzsD9+U08VtbhhCsTP9wFHyt/V}`

Difficulty: Easy