// config.js
const _0x2f4a = {
    'fragments': {
        'p1': '426B536D4E6A597A4E54',
        'p2': '5A6A55344E445A684D54',
        'p3': '4D334E445A684E545A67'
    },
    'metadata': {
        'venue': 'Starlight Arena',
        'date': '2025-07-15',
        'maxCapacity': 25000
    }
};

function loadResources(key) {
    return _0x2f4a[key] || {};
}