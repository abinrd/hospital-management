from flask import Flask, request, session, redirect, render_template, g
import sqlite3
import base64
import random
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

DATABASE = 'ctf.db'

def custom_encode(text):
    return base64.b64encode(text.encode()).decode().replace('A', '@').replace('B', '#')

def custom_decode(text):
    return base64.b64decode(text.replace('@', 'A').replace('#', 'B')).decode()

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE, check_same_thread=False)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DROP TABLE IF EXISTS users")
        cursor.execute("DROP TABLE IF EXISTS messages")

        cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT)")
        cursor.execute("CREATE TABLE messages (id INTEGER PRIMARY KEY, user_id INTEGER, message TEXT)")
        users = ["Alice", "Bob", "Charlie", "user", "findme", "notnull"]
        for user in users:
            cursor.execute("INSERT INTO users (username) VALUES (?)", (user,))
        
        cursor.execute("INSERT INTO users (id, username) VALUES (999, 'admin')")

        cursor.execute("INSERT INTO messages (user_id, message) VALUES (1, ?)", (custom_encode("Hello from Alice!"),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (2, ?)", (custom_encode("Bob here!"),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (3, ?)", (custom_encode("keep trying"),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (4, ?)", (custom_encode("This site can't be reached"),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (5, ?)", (custom_encode("working.."),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (6, ?)", (custom_encode("dGFrZSBhIGxvb2sgYXQgNTU5"),))
        cursor.execute("INSERT INTO messages (user_id, message) VALUES (559, ?)", (custom_encode("YXN0aHJhe2k5bmx0Rzl6anFrVmdJMHoxMGcwMFplVTF3aFBaeGlpfQ=="),))

        db.commit()

@app.route('/')
def index():
    return redirect('/dashboard')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        session['user_id'] = random.choice([1, 2, 3])
    
    db = get_db()
    cursor = db.execute("SELECT username FROM users WHERE id=?", (session['user_id'],))
    user = cursor.fetchone()
    
    return render_template('dashboard.html', user_id=session['user_id'], username=user['username'])

@app.route('/view_message')
def view_message():
    if 'user_id' not in session:
        return redirect('/dashboard')

    message_id = request.args.get('id', None)
    
    if message_id is None:
        return "Invalid request."

    db = get_db()
    cursor = db.execute("""
        SELECT messages.message, users.username 
        FROM messages 
        JOIN users ON messages.user_id = users.id 
        WHERE messages.user_id=?
    """, (message_id,))
    result = cursor.fetchone()

    if result:
        return render_template('message.html', 
                             message=result['message'],
                             username=result['username'])

    return render_template('message.html', error="No message found.")

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/dashboard')

if __name__ == '__main__':
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)