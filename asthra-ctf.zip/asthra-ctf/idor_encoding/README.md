# **CTF Challenge: Message IDOR & Encoding Exploitation**

## **Challenge Description**
The **Messaging System** is an internal platform where users can view their messages. However, the system does not properly enforce access controls, allowing users to **retrieve messages belonging to others** by modifying the URL parameters.

Your goal is to **find and decode the hidden admin message**, which contains the **flag**.

### 💡 **Hints:**
- The application assigns you a random **User ID** (`1`, `2`, or `3`).
- You can **view your messages** at `/view_message?id=X`.
- What happens if you **change the `id` value** in the URL?
- Some messages might contain encoded data.
- Try **decoding** the final message to get the flag!

---

## **Challenge Walkthrough**

### **1️⃣ Visit the Dashboard**
- Go to `/dashboard`.
- You’ll see your assigned **User ID** (e.g., `User ID: 2`).
- Click the **"View Your Messages"** link to visit `/view_message?id=2`.

### **2️⃣ Exploit IDOR (Insecure Direct Object Reference)**
- The URL contains `id=X`, where X is your user ID.
- Try changing the `id` to **other numbers** (e.g., `/view_message?id=5`).
- You’ll eventually find **message ID `559`**, which contains an encoded string:

```bash
 Encoded Message: YXN0aHJhe2k5bmx0Rzl6anFrVmdJMHoxMGcwMFplVTF3aFBaeGlpfQ==
```


### **3️⃣ Decode the Flag**
- The message is **Base64-encoded** with a simple transformation.
- Use Python or an online Base64 decoder:

```python
import base64

encoded_message = "YXN0aHJhe2k5bmx0Rzl6anFrVmdJMHoxMGcwMFplVTF3aFBaeGlpfQ=="
flag = base64.b64decode(encoded_message).decode()
print(flag)
```

# Flag

```bash
asthra{i9nltG9zjqkVgI0z10g00ZeU1whPZxii}
```

Difficulty: Medium