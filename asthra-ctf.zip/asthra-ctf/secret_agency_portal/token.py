import hashlib
import hmac
import base64
import json

SECRET_KEY = "enter your secret key"

def sign_token(header, payload):
    message = f"{header}.{payload}"
    signature = hmac.new(SECRET_KEY.encode(), message.encode(), hashlib.sha256).hexdigest()
    return f"{header}.{payload}.{signature}"

header = base64.b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).decode()
payload = base64.b64encode(json.dumps({"username": "agent", "role": "admin"}).encode()).decode()

token = sign_token(header, payload)
print("New JWT Token:", token)
