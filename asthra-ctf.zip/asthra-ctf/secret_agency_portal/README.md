# JWT Injection CTF Challenge

## Description
This is a CTF challenge that involves JWT (JSON Web Token) security vulnerabilities. Participants must find a way to exploit JWT authentication to escalate privileges and retrieve the flag.

## Challenge Details
- **Name:** Secret Agency Portal
- **Category:** Web Security
- **Difficulty:** Medium
- **Flag:** asthra{agency_secrets_leaked_jwt_injection}

## Challenge Setup
### Running Locally (Docker)
```sh
docker build -t jwt_ctf .

docker run -p 5000:5000 jwt_ctf
```
The challenge will be accessible at `http://localhost:5000`

## Hints
1. Check the cookies stored in the browser after logging in.
2. The login page contains some useful comments.
3. The `debug` parameter in the URL might reveal something important.
4. Modify the JWT payload and resign it to escalate privileges.
5. You can use the `token.py` to get the token.

## Walkthrough (Spoiler Alert)
1. Login with credentials:
   - **Username:** agent
   - **Password:** password123
2. Capture the `auth_token` from cookies.
3. Decode the JWT and modify the payload to `{ "username": "agent", "role": "admin" }`
4. Sign the JWT with the leaked `SECRET_KEY` from the `debug=true` parameter.
5. Use the modified JWT to access `/admin` and retrieve the flag!
