from flask import Flask, request, render_template_string, make_response
import hashlib
import base64
import hmac
import json

app = Flask(__name__)

SECRET_KEY = "sup3r_s3cr3t_k3y_2024"
FLAG = "asthra{agency_secrets_leaked_jwt_injection}"

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Secret Agency Portal</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .login-form { max-width: 400px; margin: 0 auto; }
        input { margin: 10px 0; padding: 5px; width: 100%; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="login-form">
        <h2>Secret Agency Portal</h2>
        {% if error %}<p class="error">{{ error }}</p>{% endif %}
        <form method="POST" action="/login">
            <input type="text" name="username" placeholder="Username"><br>
            <input type="password" name="password" placeholder="Password"><br>
            <input type="submit" value="Login">
        </form>
        <!--Username: agent-->
        <!--Password: password123-->
        <!-- Debug mode: {{ debug }} -->
    </div>
</body>
</html>
"""

def create_token(data):

    header = base64.b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).decode()
    payload = base64.b64encode(json.dumps(data).encode()).decode()

    signature = hmac.new(
        SECRET_KEY.encode(),
        f"{header}.{payload}".encode(),
        hashlib.sha256
    ).hexdigest()
    
    return f"{header}.{payload}.{signature}"

def verify_token(token):
    try:
        header_b64, payload_b64, signature = token.split('.')
        expected_signature = hmac.new(
            SECRET_KEY.encode(),
            f"{header_b64}.{payload_b64}".encode(),
            hashlib.sha256
        ).hexdigest()
        
        if signature != expected_signature:
            return None
            
        payload = json.loads(base64.b64decode(payload_b64))
        return payload
    except:
        return None

@app.route('/')
@app.route('/')
def index():
    debug = request.args.get('debug', 'false')
    if debug.lower() == 'true':
        debug = f"true (SECRET_KEY: {SECRET_KEY})"
    
    return render_template_string(LOGIN_TEMPLATE, debug=debug, error=None)

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if username == "agent" and password == "password123":
        token = create_token({"username": username, "role": "agent"})
        resp = make_response("Login successful! Check your cookies.")
        resp.set_cookie('auth_token', token)
        return resp
    
    return render_template_string(LOGIN_TEMPLATE, error="Invalid credentials", debug="false")

@app.route('/admin')
def admin():
    token = request.cookies.get('auth_token')
    if not token:
        return "Unauthorized", 401
        
    payload = verify_token(token)
    if not payload or payload.get('role') != "admin":
        return "Access denied", 403
        
    return f"Welcome, admin! Here's your flag: {FLAG}"

if __name__ == '__main__':
    app.run(debug=True)