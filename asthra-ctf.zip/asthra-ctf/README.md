# Asthra CTF 25

Welcome to the repo for asthra CTF 2025! This repo contains all the challenges deployed in asthra ctf. Please make your challenges in your own folders, set up similar to challenge 0.

## Flag format

Please ensure your flags are in the format `asthra{custom value}`, where `custom value` is any string of your choosing. This will be used to award points to those who solve your challenge.

## Note to challenge creators
Please add a README to your respective challenge outlining how to solve it. Also add a Dockerfile to make it easy to host the challenges.