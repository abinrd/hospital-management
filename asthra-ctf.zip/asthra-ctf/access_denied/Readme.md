
# Access Denied Challenge

## Description

In this challenge, you need to interact with an Express server that has three routes:
- `GET /`: Returns a welcome message.
- `GET /secret`: Returns a 403 status with "Access Denied".
- `PUT /secret`: Reveals the flag.

## Solution

1. Access the home page:
    ```sh
    curl http://localhost:3000/
    ```

2. Try to access the secret page (this will be denied):
    ```sh
    curl http://localhost:3000/secret
    ```

3. Use the PUT method to reveal the flag:
    ```sh
    curl -X PUT http://localhost:3000/secret
    ```

4. The response will contain the flag:
    ```
    The flag is: asthra{you_found_the_secret}
    ```