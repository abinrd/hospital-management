const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.get('/', (req, res) => {
    res.send('Welcome to the home page!');
});

app.get('/secret', (req, res) => {
    res.status(403).send('Access Denied');
});

app.put('/secret', (req, res) => {
    const flag = 'asthra{you_found_the_secret}';
    res.send(`The flag is: ${flag}`);
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
