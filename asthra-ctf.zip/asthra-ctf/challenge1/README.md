# Asthra CTF Challenge 1

## Challenge Details
This is a simple Linux terminal emulation challenge hosted in a web environment.

You will be presented with a Linux terminal UI in your browser.
Type commands to explore the environment. Use help to see available commands.
Look for hidden files and decrypt encoded data to reveal the flag.
The flag is in the format: asthra{...}.

Your goal is to find the hidden flag in the system!
Difficulty: Easy
