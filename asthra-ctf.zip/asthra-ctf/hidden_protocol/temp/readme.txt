flag is hidden in this executable file download it and find flag
break it down through ♻️