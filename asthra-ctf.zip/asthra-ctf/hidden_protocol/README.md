# Hidden Protocol Challenge - Solution Guide

This guide provides detailed steps to solve the Hidden Protocol Challenge using Radare2 (r2) for binary analysis.

## Challenge Overview

The Hidden Protocol Challenge requires you to interact with a custom binary protocol to authenticate and retrieve a flag. The binary implements a service that accepts hex-encoded packets and responds with hex-encoded responses.

**Objective**: Reverse engineer the protocol, authenticate to the server, and retrieve the flag: `asthra{abcdqwertpoiuctfasthra}`

## Prerequisites

- Radare2 (r2) - A reverse engineering framework
- Python 3
- Basic understanding of C/assembly
- Hex editor or converter (optional)

## Step 1: Initial Analysis with Radare2

First, let's analyze the binary:

```bash
# Start radare2 in analysis mode
r2 -A temp/hidden_protocol

# Alternative command if you need more thorough analysis
r2 -AA temp/hidden_protocol
```

### Examining Program Structure

After opening the binary in r2, let's identify functions and strings:

```bash
# List all functions
afl

# Look for main function
afl~main

# Examine the main function
s main
pdf

# List all strings in the binary
iz
```

The `iz` command will reveal helpful strings including:
- "CTFP" (Magic bytes)
- "this_is_secret_key" (The authentication key)
- Various debug messages and hints

## Step 2: Understanding the Protocol

From our analysis, we learn that the protocol has the following structure:

### Packet Structure
- First 4 bytes: Magic bytes ("CTFP")
- Byte 5: Version (1)
- Byte 6: Command (0x01 for auth, 0x02 for flag)
- Byte 7: Data length
- Byte 8: Reserved byte
- Remaining bytes: Command-specific data

Let's look more deeply at the authentication function:

```bash
# Find the process_packet function
afl~process_packet

# Examine process_packet
s sym.process_packet
pdf
```

This will show us how packet processing works, including authentication checks and flag retrieval logic.

## Step 3: Crafting Authentication Packet

Based on our analysis, we need to create an authentication packet:

```python
# Python code for creating auth packet
import binascii

# Constants
MAGIC_BYTES = b'CTFP'
VERSION = 1
CMD_AUTHENTICATE = 0x01

# Secret key found in the binary
SECRET_KEY = b'this_is_secret_key'

# Create authentication packet
auth_packet = bytearray()
auth_packet.extend(MAGIC_BYTES)       # Magic bytes
auth_packet.append(VERSION)           # Version
auth_packet.append(CMD_AUTHENTICATE)  # Command: Authenticate
auth_packet.append(len(SECRET_KEY))   # Length of key
auth_packet.append(0)                 # Reserved byte
auth_packet.extend(SECRET_KEY)        # Secret key

print(f"Auth packet (hex): {binascii.hexlify(auth_packet).decode()}")
```

This should output a hex string that you can send to the program. The format will be similar to: 
`43544650010117000this_is_secret_key` (the actual hex encoding will differ).

## Step 4: Crafting Flag Retrieval Packet

After successful authentication, we need to retrieve the flag:

```python
#!/usr/bin/env python3
import binascii

# Define constants
MAGIC_BYTES = b'CTFP'
VERSION = 1
CMD_AUTHENTICATE = 0x01
CMD_GET_FLAG = 0x02
SECRET_KEY = b'this_is_secret_key'

# Create authentication packet
def create_auth_packet():
    packet = bytearray()
    packet.extend(MAGIC_BYTES)       # Magic bytes
    packet.append(VERSION)           # Version
    packet.append(CMD_AUTHENTICATE)  # Command: Authenticate
    packet.append(len(SECRET_KEY))   # Length of the key
    packet.append(0)                 # Reserved byte
    packet.extend(SECRET_KEY)        # The key itself
    return packet

# Create flag retrieval packet
def create_flag_packet():
    packet = bytearray()
    packet.extend(MAGIC_BYTES)     # Magic bytes
    packet.append(VERSION)         # Version
    packet.append(CMD_GET_FLAG)    # Command: Get Flag
    packet.append(0)               # Data length
    packet.append(0)               # Reserved byte
    packet.append(1)               # Auth token (any non-zero value)
    return packet

# Generate and print packets
auth_packet = create_auth_packet()
flag_packet = create_flag_packet()

print(f"Authentication packet (hex):")
print(f"{binascii.hexlify(auth_packet).decode()}")

print(f"\nFlag retrieval packet (hex):")
print(f"{binascii.hexlify(flag_packet).decode()}")
```

## Step 6: Decoding the Flag

If you run into issues with the script above, you can run the program manually and send the hex-encoded packets:

1. Run the binary: `./temp/hidden_protocol`
2. Send the auth packet hex string
3. Send the flag packet hex string
4. Parse the hex response to get the flag

The response will be a hex-encoded packet. The flag starts at the 9th byte (after the header) and continues for the length specified in the 8th byte. 

Example response: `43544650010119006173746872617b61626364717765727470...`

The first 8 bytes are the header: `43 54 46 50 01 01 19 00`
- `43 54 46 50` = "CTFP" (magic bytes)
- `01` = Version
- `01` = Command (GET_FLAG response)
- `19` = Length of the flag (25 bytes)
- The rest is the flag data

## Alternative Method: Using Interactive Mode in r2

If you prefer to use r2's debugging capabilities:

```bash
# Start r2 in debugging mode
r2 -d temp/hidden_protocol

# Set breakpoint at process_packet function
db sym.process_packet

# Run the program
dc

# Once the breakpoint is hit, examine registers and memory
dr
px @ rdi  # Examine packet data

# Continue execution to see responses
dc
```

## Conclusion

This challenge teaches several important reverse engineering concepts:
1. Binary analysis using Radare2
2. Understanding custom network protocols
3. Crafting binary packets for exploitation
4. Automating exploit scripts with Python

By following these steps, you'll retrieve the flag: `asthra{abcdqwertpoiuctfasthra}`

## Additional Tips

- Use `pf` in r2 to create custom data structure formats for better visualization
- Look for debugging strings that might give away key information
- Pay attention to XOR operations, which are often used for simple obfuscation
- The simplified challenge includes many hints, but real CTF challenges might require more thorough analysis


# Flag

```bash
asthra{umlbxfttywiiqmhajaebxlrymk}
```

Difficulty: Hard